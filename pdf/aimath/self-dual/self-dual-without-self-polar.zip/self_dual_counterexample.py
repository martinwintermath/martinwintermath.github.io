#!/usr/bin/env python3
"""Exact incidence certificate for the self-dual 10-dimensional polytope construction.

Python 3.9+, standard library only. No floating point or external packages.
Run: python3 self_dual_counterexample.py
Full symmetry enumeration: python3 self_dual_counterexample.py --enumerate
Export complete incidence data: ... --export-json self_dual_incidence.json

This checks finite combinatorial claims. It does not prove convex realizability
or the BEK nongeometrizability theorem; the geometric proof and external reference are given in the accompanying paper.
"""

import argparse
import json
from collections import Counter, defaultdict
from itertools import combinations


FACETS_P = (
    (0, 1, 2, 6), (0, 1, 3, 7), (1, 2, 7, 8), (1, 6, 8, 9),
    (0, 2, 3, 6), (1, 2, 3, 7), (2, 7, 8, 9), (1, 2, 6, 9),
    (0, 3, 5, 6), (0, 4, 5, 7), (5, 7, 8, 9), (4, 5, 6, 8),
    (3, 4, 5, 6), (0, 3, 4, 7), (4, 5, 7, 9), (4, 6, 8, 9),
    (0, 1, 5, 6), (0, 1, 5, 7), (1, 5, 7, 8), (1, 5, 6, 8),
    (2, 3, 4, 6), (2, 3, 4, 7), (2, 4, 7, 9), (2, 4, 6, 9),
    (0, 3, 4, 5), (0, 1, 2, 3), (4, 5, 8, 9), (1, 2, 8, 9),
)
ALPHA = {0: 9, 9: 0, 1: 4, 4: 1, 2: 5, 5: 2, 3: 8, 8: 3, 6: 7, 7: 6}
F = (0, 1, 2, 6)


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def suffix(face):
    return "_".join(map(str, sorted(face)))


def qvertex(face):
    return "q" + suffix(face)


def vertices(facets):
    return set().union(*facets.values())


def closure(facets, subset):
    containing = [s for s in facets.values() if subset <= s]
    return set.intersection(*containing) if containing else vertices(facets)


def is_face(facets, subset):
    return closure(facets, subset) == subset


def edges(facets):
    """A pair is an edge exactly when its facet closure is that pair."""
    vs = sorted(vertices(facets))
    fs = list(facets.values())
    incident = {v: {i for i, s in enumerate(fs) if v in s} for v in vs}
    result = []
    for u, v in combinations(vs, 2):
        common = incident[u] & incident[v]
        if common and set.intersection(*(fs[i] for i in common)) == {u, v}:
            result.append((u, v))
    return result


def ridges_of(facets, facet):
    """Maximal proper intersections with a facet are precisely its ridges."""
    intersections = {frozenset(facets[facet] & s)
                     for h, s in facets.items() if h != facet}
    result = []
    for r in sorted(intersections, key=lambda s: (len(s), sorted(s))):
        if not any(r < other for other in intersections):
            containing = [h for h, s in facets.items() if r <= s]
            check(len(containing) == 2, "Ridge must lie in two facets")
            result.append((set(r), next(h for h in containing if h != facet)))
    return result


def truncate_edge(facets, endpoints, index):
    """Shallow edge truncation: replace crossing edges by their cut vertices."""
    w = set(endpoints)
    check(len(w) == 2 and is_face(facets, w), "Cut target is not an edge")
    crossing = [(u, v) for u, v in edges(facets) if (u in w) != (v in w)]
    fresh = {}
    for j, (u, v) in enumerate(crossing):
        fresh[f"c{index}:{j:03d}"] = {
            h for h, s in facets.items() if u in s and v in s}
    result = {h: (s - w) | {n for n, hs in fresh.items() if h in hs}
              for h, s in facets.items()}
    result[f"C{index}"] = set(fresh)
    return result, crossing


def add_beyond_ridge(facets, visible, index):
    """Replace two visible facets by cones over their horizon ridges."""
    visible = set(visible)
    check(len(visible) == 2, "Need two visible facets")
    hs = sorted(visible)
    check(any(other == hs[1] for _, other in ridges_of(facets, hs[0])),
          "Visible facets do not meet in a ridge")
    horizon = []
    for h in hs:
        for r, other in ridges_of(facets, h):
            if other not in visible:
                horizon.append((h, other, r))
    result = {h: set(s) for h, s in facets.items() if h not in visible}
    for j, (_, _, r) in enumerate(horizon):
        result[f"N{index}:{j:03d}"] = r | {f"z{index}"}
    return result, horizon


def construct():
    p = {frozenset(f) for f in FACETS_P}
    check(len(p) == 28, "BEK facet count")
    check({frozenset(ALPHA[v] for v in f) for f in p} == p,
          "Alpha does not preserve BEK facets")
    check([sum({0, j} <= f for f in p) for j in (1, 2, 6)] == [5, 3, 4],
          "Distinguishing edge-valences")
    check(not any(sum(v in f for f in p) >= len(p) - 1 for v in range(10)),
          "BEK is a pyramid")
    pv = {f"p{v}" for v in range(10)}
    qv = {qvertex(f) for f in FACETS_P}
    x = {f"A{v}": pv | {qvertex(f) for f in FACETS_P if v in f}
         for v in range(10)}
    x.update({"B" + suffix(f): qv | {f"p{v}" for v in f}
              for f in FACETS_P})
    xv = vertices(x)
    r = {"S:" + h: {t + ":" + v for t in ("b", "m") for v in s}
         for h, s in x.items()}
    r.update({"T:" + h: {"a"} | {"m:" + v for v in s}
              for h, s in x.items()})
    r["bottom"] = {"b:" + v for v in xv}
    check((len(vertices(r)), len(r)) == (77, 77), "Roofed-prism counts")
    af = tuple(sorted(ALPHA[v] for v in F))
    cut_targets = [("b:p0", "b:" + qvertex(F)),
                   ("b:p9", "b:" + qvertex(af))]
    roof_targets = [("T:A0", "T:B" + suffix(af)),
                    ("T:A9", "T:B" + suffix(F))]
    logs = {"cuts": [], "additions": []}
    for i, target in enumerate(cut_targets):
        degrees = Counter(v for edge in edges(r) for v in edge)
        check([degrees[v] for v in target] == [36, 15], "Cut endpoint degrees")
        r, crossing = truncate_edge(r, target, i)
        check(len(crossing) == 49, "Truncation vertex count")
        logs["cuts"].append({"target": list(target), "crossing_edges": crossing})
    for i, target in enumerate(roof_targets):
        r, horizon = add_beyond_ridge(r, target, i)
        check(len(horizon) == 49, "Ridge-addition facet count")
        logs["additions"].append({"visible_facets": list(target),
                                   "horizon": [[h, k, sorted(s)]
                                               for h, k, s in horizon]})
    return x, r, logs


def delta_q_vertex(v):
    if v.startswith("p"):
        return "A" + v[1:]
    f = tuple(map(int, v[1:].split("_")))
    return "B" + suffix(ALPHA[u] for u in f)


def delta_q_facet(h):
    if h.startswith("A"):
        return "p" + str(ALPHA[int(h[1:])])
    return "q" + h[1:]


def sigma_vertex(v):
    if v.startswith("p"):
        return "p" + str(ALPHA[int(v[1:])])
    return "q" + suffix(ALPHA[int(u)] for u in v[1:].split("_"))


def incidence_graph(facets):
    """Bipartite graph; prefixes distinguish vertices from facets."""
    adj = {"V|" + v: set() for v in vertices(facets)}
    adj.update({"F|" + h: set() for h in facets})
    for h, s in facets.items():
        for v in s:
            adj["V|" + v].add("F|" + h)
            adj["F|" + h].add("V|" + v)
    return adj


def refine_pair(adj, left, right):
    """Simultaneous exact color refinement for graph-isomorphism search."""
    while True:
        signatures = []
        for colors in (left, right):
            signatures.append({v: (colors[v], tuple(sorted(Counter(
                colors[w] for w in adj[v]).items()))) for v in adj})
        ids = {s: i for i, s in enumerate(sorted(
            set(signatures[0].values()) | set(signatures[1].values())))}
        nl = {v: ids[s] for v, s in signatures[0].items()}
        nr = {v: ids[s] for v, s in signatures[1].items()}
        if Counter(nl.values()) != Counter(nr.values()):
            return None
        stable = len(set(nl.values())) == len(set(left.values()))
        left, right = nl, nr
        if stable:
            return left, right


def isomorphisms(adj, dual=False, forced=()):
    """Enumerate exactly by color refinement and exhaustive individualization.

    Both graphs have the same adjacency. Their initial colors enforce preserving
    the two parts (automorphisms) or exchanging the parts (dualities).
    """
    left = {v: int(v.startswith("F|")) for v in adj}
    right = {v: int(v.startswith("F|")) ^ int(dual) for v in adj}
    for i, (u, v) in enumerate(forced, 2):
        check(u in adj and v in adj, "Unknown forced node")
        left[u] = right[v] = i

    def search(lc, rc):
        refined = refine_pair(adj, lc, rc)
        if refined is None:
            return
        lc, rc = refined
        groups_l, groups_r = defaultdict(list), defaultdict(list)
        for v in sorted(adj):
            groups_l[lc[v]].append(v)
            groups_r[rc[v]].append(v)
        ambiguous = [(len(vs), c) for c, vs in groups_l.items() if len(vs) > 1]
        if not ambiguous:
            mapping = {groups_l[c][0]: groups_r[c][0] for c in groups_l}
            check(all({mapping[w] for w in adj[v]} == adj[mapping[v]] for v in adj),
                  "Search returned a non-isomorphism")
            yield mapping
            return
        _, color = min(ambiguous)
        u = groups_l[color][0]
        fresh = max(max(lc.values()), max(rc.values())) + 1
        for v in groups_r[color]:
            nl, nr = dict(lc), dict(rc)
            nl[u] = nr[v] = fresh
            yield from search(nl, nr)

    yield from search(left, right)


def audit(x, q):
    check((len(vertices(q)), len(q)) == (173, 173), "Final counts")
    incident = Counter(v for s in q.values() for v in s)
    expected = {
        "a": {128: 1}, "z": {49: 2},
        "m:p": {74: 2, 85: 2, 93: 6}, "m:q": {80: 8, 109: 20},
        "b:": {21: 2, 23: 6, 33: 26},
        "c": {15: 4, 16: 64, 17: 4, 18: 14, 21: 2, 33: 10},
    }
    for prefix, wanted in expected.items():
        actual = dict(Counter(incident[v] for v in vertices(q) if v.startswith(prefix)))
        check(actual == wanted, f"Incidence histogram mismatch: {prefix}")
    check({h for h, s in q.items() if len(s) == 49} == {"C0", "C1"},
          "Intrinsic truncation-facet recognition")
    check([len(q[h]) for h in ("C0", "C1")] == [49, 49], "Cut facets")
    neighbors = {v: set() for v in vertices(q)}
    for u, v in edges(q):
        neighbors[u].add(v)
        neighbors[v].add(u)
    m = {"m:" + v for v in vertices(x)}
    distinguished = {"a", "z0", "z1"}
    check(neighbors["a"] - {"z0", "z1"} == m, "Middle recognition")
    for v in m:
        outer = neighbors[v] - m - distinguished
        check(len(outer) == 1, "Unique outside neighbor")
        w = next(iter(outer))
        xv = v[2:]
        af = tuple(sorted(ALPHA[u] for u in F))
        for i, targets in enumerate(({"p0", qvertex(F)}, {"p9", qvertex(af)})):
            check((w in q[f"C{i}"]) == (xv in targets), "Edge marking recovery")
    roof_pairs = [("A0", "B" + suffix(ALPHA[u] for u in F)),
                  ("A9", "B" + suffix(F))]
    for i, pair in enumerate(roof_pairs):
        traces = [s & m for s in q.values() if f"z{i}" in s and "a" not in s]
        check({frozenset(t) for t in traces}
              == {frozenset("m:" + v for v in x[h]) for h in pair},
              "Roof marking recovery")
        check(len(traces) == 2, "Roof marking facet count")
    check({h for h, s in q.items() if not s & distinguished and s & m}
          == {"S:" + h for h in x}, "Side-facet recognition")
    for h, s in x.items():
        check(is_face(q, {"m:" + v for v in s}), "Middle facet failed to survive")
    check(all(is_face(x, {v[2:] for v in s & m}) for s in q.values()),
          "An extra middle face was introduced")
    pm = {f"m:p{v}" for v in range(10)}
    check(is_face(q, pm), "BEK face did not survive")
    traces = {frozenset(s & pm) for s in q.values() if s & pm != pm}
    maximal = {s for s in traces if not any(s < t for t in traces)}
    check(maximal == {frozenset(f"m:p{v}" for v in f) for f in FACETS_P},
          "BEK-face facets differ from the input")
    print("PASS: counts, all incidence histograms, both marking recoveries,")
    print("      middle boundary, side recognition, and surviving BEK face.")
    return incident


def audit_dualities(x, q, enumerate_all):
    graph = incidence_graph(q)
    forced = [("V|m:" + v, "F|S:" + delta_q_vertex(v))
              for v in sorted(vertices(x))]
    forced += [("F|S:" + h, "V|m:" + delta_q_facet(h)) for h in sorted(x)]
    delta = next(isomorphisms(graph, dual=True, forced=forced), None)
    check(delta is not None, "Specified middle duality does not extend")
    for v in vertices(x):
        u = "V|m:" + v
        check(delta[delta[u]] == "V|m:" + sigma_vertex(v), "Specified square")
    check(all(delta[delta[delta[delta[u]]]] == u for u in graph), "Delta^4 != 1")
    print("PASS: explicit duality extends the displayed formulas; square is sigma;")
    print("      its fourth power is the identity on the complete incidence graph.")
    results = {"explicit_duality": delta}
    if enumerate_all:
        autos = list(isomorphisms(graph))
        duals = list(isomorphisms(graph, dual=True))
        check(len(autos) == 2 and len(duals) == 2, "Full symmetry counts")
        for d in duals:
            for v in vertices(x):
                u = "V|m:" + v
                check(d[d[u]] == "V|m:" + sigma_vertex(v), "Arbitrary duality square")
            check(all(d[d[d[d[u]]]] == u for u in graph), "Duality order")
        print("PASS: exhaustive search finds exactly two automorphisms and two")
        print("      dualities; both dualities have order four and the required square.")
        results.update(automorphisms=autos, dualities=duals)
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--enumerate", action="store_true", help="Enumerate all symmetries")
    parser.add_argument("--export-json", metavar="PATH", help="Write complete incidence data")
    args = parser.parse_args()
    x, q, logs = construct()
    incident = audit(x, q)
    symmetries = audit_dualities(x, q, args.enumerate)
    if args.export_json:
        data = {"dimension": 10, "input_facets": FACETS_P, "alpha": ALPHA,
                "Q_facets": {h: sorted(s) for h, s in sorted(x.items())},
                "S_vertices": sorted(vertices(q)),
                "S_facets": {h: sorted(s) for h, s in sorted(q.items())},
                "vertex_incidence_counts": dict(sorted(incident.items())),
                "operations": logs, "symmetries": symmetries}
        with open(args.export_json, "w", encoding="utf-8") as out:
            json.dump(data, out, indent=2, sort_keys=True)
            out.write("\n")
        print("Exported complete incidence data to", args.export_json)
    print("All requested finite checks passed.")


if __name__ == "__main__":
    main()
