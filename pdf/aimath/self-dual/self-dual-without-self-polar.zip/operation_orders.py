"""Supplementary finite audit. Run with Python 3.9+; no external libraries.

The source data and graph-isomorphism routine are imported from the supplied
checker. Operation routines below are separate implementations.
"""
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
from itertools import combinations, permutations

spec = importlib.util.spec_from_file_location('checker', HERE / 'self_dual_counterexample.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
pv = {'p'+str(v) for v in range(10)}
qv = {'q'+'_'.join(map(str,sorted(f))) for f in c.FACETS_P}
q = {'A'+str(v): pv | {'q'+'_'.join(map(str,sorted(f))) for f in c.FACETS_P if v in f} for v in range(10)}
q.update({'B'+'_'.join(map(str,sorted(f))):qv | {'p'+str(v) for v in f} for f in c.FACETS_P})
af = tuple(sorted(c.ALPHA[v] for v in c.F))
fstr = '_'.join(map(str,c.F))
afstr = '_'.join(map(str,af))
logs = {'cuts':[{'target':['b:p0','b:q'+fstr]}, {'target':['b:p9','b:q'+afstr]}],
        'additions':[{'visible_facets':['T:A0','T:B'+afstr]}, {'visible_facets':['T:A9','T:B'+fstr]}]}
initial = {'S:'+h: {t+':'+v for t in ('b','m') for v in s} for h,s in q.items()}
initial.update({'T:'+h: {'a'} | {'m:'+v for v in s} for h,s in q.items()})
initial['bottom'] = {'b:'+v for v in c.vertices(q)}

def all_edges(fs):
    vs = set().union(*fs.values())
    incidences = {v: {h for h,s in fs.items() if v in s} for v in vs}
    for u,v in combinations(sorted(vs),2):
        common = incidences[u] & incidences[v]
        if common and set.intersection(*(fs[h] for h in common)) == {u,v}:
            yield u,v

def ridge_sets(fs,h):
    candidates = {frozenset(s & fs[h]) for k,s in fs.items() if k != h}
    return [r for r in candidates if not any(r < t for t in candidates)]

def run(order):
    fs = {h:set(s) for h,s in initial.items()}
    ancestry = {v:frozenset([v]) for v in c.vertices(fs)}
    for op in order:
        i = int(op[1])
        if op[0] == 'c':
            w = set(logs['cuts'][i]['target'])
            assert tuple(sorted(w)) in list(all_edges(fs))
            crossing = [e for e in all_edges(fs) if len(set(e) & w) == 1]
            fresh = {}
            for u,v in crossing:
                origins = ancestry[u] | ancestry[v]
                assert len(origins) == 2
                name = 'cut'+str(i)+'['+','.join(sorted(origins))+']'
                fresh[name] = {h for h,s in fs.items() if {u,v} <= s}
                ancestry[name] = origins
            assert len(fresh) == 49
            fs = {h:(s-w) | {n for n,hs in fresh.items() if h in hs} for h,s in fs.items()}
            fs['C'+str(i)] = set(fresh)
        else:
            visible = set(logs['additions'][i]['visible_facets'])
            h,k = sorted(visible)
            assert frozenset(fs[h] & fs[k]) in ridge_sets(fs,h)
            horizon = []
            for h in visible:
                for r in ridge_sets(fs,h):
                    owners = {k for k,s in fs.items() if r <= s}
                    assert len(owners) == 2
                    if not owners <= visible:
                        horizon.append(r)
            assert len(horizon) == 49 and len(set(horizon)) == 49
            fs = {h:s for h,s in fs.items() if h not in visible}
            for j,r in enumerate(sorted(horizon,key=lambda r: sorted(r))):
                fs['new'+str(i)+':'+str(j)] = set(r) | {'z'+str(i)}
    return frozenset(frozenset(s) for s in fs.values())

base = run(('c0','c1','r0','r1'))
for order in permutations(('c0','c1','r0','r1')):
    assert run(order) == base, order
print('PASS: all 24 operation orders have identical facet sets after canonical cut-vertex naming.')

with open(HERE / 'self_dual_incidence.json') as stream:
    supplied = json.load(stream)
names = {v:v for v in set().union(*initial.values())}
original = {v:frozenset([v]) for v in names}
for i,cut in enumerate(supplied['operations']['cuts']):
    for j,(u,v) in enumerate(cut['crossing_edges']):
        origins = original[u] | original[v]
        name = 'c'+str(i)+':'+format(j,'03d')
        original[name] = origins
        names[name] = 'cut'+str(i)+'['+','.join(sorted(origins))+']'
names.update(z0='z0',z1='z1')
expected = frozenset(frozenset(names[v] for v in s) for s in supplied['S_facets'].values())
assert base == expected
print('PASS: all these orders agree with the supplied complete JSON incidence data.')

p = {'f'+str(i):set(f) for i,f in enumerate(c.FACETS_P)}
autos = list(c.isomorphisms(c.incidence_graph({h:{str(v) for v in s} for h,s in p.items()})))
stabilizer = [a for a in autos if a['V|0'] == 'V|0' and {a['V|'+str(v)] for v in c.F} == {'V|'+str(v) for v in c.F}]
print('BEK automorphism count:',len(autos),'pair stabilizer count:',len(stabilizer))

g = {('v',v):{('f',h) for h,s in p.items() if v not in s} for v in range(10)}
g.update({('f',h):{('v',v) for v in range(10) if v not in s} for h,s in p.items()})
visited = set()
todo = [next(iter(g))]
while todo:
    n = todo.pop()
    if n in visited: continue
    visited.add(n)
    todo.extend(g[n]-visited)
assert visited == set(g)
print('PASS: BEK vertex-facet nonincidence graph is connected; the dual graph is its transpose.')
