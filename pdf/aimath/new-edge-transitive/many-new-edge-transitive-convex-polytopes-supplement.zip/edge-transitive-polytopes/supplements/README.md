# Supplementary material

This directory accompanies *Many new edge-transitive convex polytopes*.

## Reproduce the computations

Run from this directory with Python 3.10 or newer:

    python3 run_all.py

Do not use **python3 -O**: the certificates are checked by assertions.
The runner uses the same interpreter for every program, stops on a failed
assertion or other error, and records the output of each program in its
corresponding .log file. Computation is exact. There are no third-party
dependencies and all input files are included.

The distributed results were generated with Python 3.12.14. The complete
runner returned:

    PASS verify_binary_inputs.py
    PASS verify_seed_polytopes.py
    PASS verify_structural_properties.py
    PASS verify_parameters.py
    All supplementary checks passed.

## Programs and certificates

**verify_binary_inputs.py** supplies binary linear algebra, constructs the
Golay code and its cosets, verifies the covering-radius and sextet data
and the explicit deep-layer face, and checks the smallest Hamming and
moment polytopes. It records 112 vertices of the first Hamming-complement
example and 56 vertices of the dimension-seven affine/moment example. It
enumerates all 32,768 even moment matrices at m = 5, finds 13,888
nonsingular matrices and a 65,536-word kernel, giving 910,163,968 vertices.
It also verifies explicit small nonuniform faces.
Output: **binary_results.json**.

**verify_seed_polytopes.py** reconstructs the large and small Witt designs
and their permutation actions, using Schreier stabilizers and exact
orbits. It verifies the 113,344- and 792-element basis orbits, degrees 90
and 30, and extension-pair orbit sizes 240 and 30. It also verifies the
signed affine example. For the Golay deep
layer it verifies all 488,796 coset/pair tests and provides midpoint
witnesses for every nonneighbor of a fixed vertex among all 7,254,016
vertices. It also verifies the m = 4 Hamming
example, the complete m = 5 nonsingular moment orbit and local graph, and
942,152 four- and six-coordinate difference tests. Outputs:
**seed_results.json** and **mathieu_certificates.json**.

**verify_structural_properties.py** verifies the exact reflection indices
and spanning sets for H_3, H_4, P_5 and P_7, and generation of AGL(3,2)
by exact 2-reflections. It checks midpoint certificates for all 1,024
labelled graphs on five vertices in the binary even delta-matroid
construction. Output: **structural_results.json**.

**verify_parameters.py** reproduces the numerical parameter tables and
checks the design data for facet counts 30, 156 and 807. It enumerates the
degree-twelve Mathieu action and its involutions, verifies generation by
the 495 index-four involutions, and constructs the index-eight conjugacy
class of size 11,385 in the degree-twenty-four action. It also constructs
the edge graphs of H_3 and the rectified 8-crosspolytope, checks that both
have 112 vertices and 1,344 edges, and distinguishes their induced
neighbor graphs by degrees ten and eleven. Output:
**parameter_results.json**.

**run_all.py** executes all four programs. Its **verification_manifest.json**
records the Python version, completion time, overall status and SHA-256
hashes of every program and the two input files.

The checks have an explicitly finite scope. They do not enumerate all
vertices of P_5 or the rank-eighteen signed lift. Their counts follow from
the certified moment fibers or basis supports. The proofs in the paper
establish the assertions for every family parameter.

## Input provenance

**M24.g1** and **M24.g2** are the degree-twenty-four permutation generators
from the ATLAS of Finite Group Representations:

- [Representation](https://brauer.maths.qmul.ac.uk/Atlas/v3/permrep/M24G1-p24B0)
- [First generator](https://brauer.maths.qmul.ac.uk/Atlas/spor/M24/gap/M24G1-p24B0.g1)
- [Second generator](https://brauer.maths.qmul.ac.uk/Atlas/spor/M24/gap/M24G1-p24B0.g2)

The programs parse only the permutation cycles in these data files; they
do not execute the files as GAP code. The degree-twelve action is derived
by restricting the stabilizer of a Golay dodecad.

SHA-256:

    M24.g1  14a7ea197f358dc995270f089105c6ac8efaa901871d2194330cef6688940db5
    M24.g2  fa9883fa830202639e8c5ceb4f643634d6792a28328b772b11581273adab1496
