#!/usr/bin/env python3
"""Run the supplementary verification with the current Python interpreter."""
from pathlib import Path
from datetime import datetime, timezone
import subprocess, sys, hashlib, json

ROOT=Path(__file__).resolve().parent
if sys.version_info<(3,10):
    raise SystemExit("Python 3.10 or newer is required.")
if not __debug__:
    raise SystemExit("Assertions must be enabled; do not use python -O.")
names=['verify_binary_inputs.py','verify_seed_polytopes.py',
       'verify_structural_properties.py','verify_parameters.py']
for name in names:
    print('Running '+name,flush=True)
    with (ROOT/(name.removesuffix('.py')+'.log')).open('w') as output:
        subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,stdout=output,
                       stderr=subprocess.STDOUT,check=True)
    print('PASS '+name,flush=True)
files=names+['run_all.py','M24.g1','M24.g2']
manifest={'python':sys.version,'utc_finished':datetime.now(timezone.utc).isoformat(),
          'status':'all passed','sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                                         for name in files}}
(ROOT/'verification_manifest.json').write_text(json.dumps(manifest,indent=2))
print('All supplementary checks passed.',flush=True)
