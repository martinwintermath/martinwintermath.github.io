#!/usr/bin/env python3
"""Exact reflection-generator and small delta-matroid checks."""
from itertools import combinations
from collections import Counter
from pathlib import Path
from verify_seed_polytopes import rank2, moment, mask, points, affine_generators, closure, comp, RESULTS
import json

ROOT=Path(__file__).resolve().parent

def reflection_checks():
    results=[]
    for m,flatdim in [(3,2),(4,2),(5,3),(7,3)]:
        n=1<<m
        flats=[]; checked=0
        for free in combinations(range(m),flatdim):
            fixed=sorted(set(range(m))-set(free))
            for value in range(1<<len(fixed)):
                T=mask(a for a in range(n) if all((a>>j&1)==(value>>i&1) for i,j in enumerate(fixed)))
                flats.append(T)
                # f is 1 on T, and nonconstant, with direction b in T.
                j=fixed[0]; c=(value&1)^1; b=1<<free[0]
                tau=tuple(a^((((a>>j)&1)^c)*b) for a in range(n))
                assert comp(tau,tau)==tuple(range(n))
                assert mask(tau[a] for a in points(T))==T
                assert all(tau[a]!=a for a in points(T))
                # Signed involution (tau,T): each moved 2-cycle gives one
                # negative eigenvalue, fixed negative coordinates add one.
                moved=sum(tau[a]!=a for a in range(n))
                fixed_neg=sum(tau[a]==a and T>>a&1 for a in range(n))
                assert moved//2==n//4 and moved//2+fixed_neg==n//4
                checked+=2
        dimension=rank2(flats)
        expected=n-1-m if flatdim==2 else n-1-m-m*(m-1)//2
        assert dimension==expected
        if flatdim==3: assert all(moment(T,m)==[0]*(m+1) for T in flats)
        results.append({'m':m,'flat_dimension':flatdim,'flat_generators':len(flats),
            'kernel_span_dimension':dimension,'exact_k':n//4,'signed_involutions_checked':checked})
    # For P3, generate AGL(3,2) using only exact 2-reflections.
    m=3;n=8;gens=[]
    for i in range(m):
        for j in range(m):
            if i!=j:
                for c in [0,1]:
                    p=tuple(a^((((a>>j)&1)^c)<<i) for a in range(n))
                    assert sum(a!=p[a] for a in range(n))==4
                    gens.append(p)
    assert len(closure(gens,n))==1344
    return {'families':results,'P3_group_generated_by_exact_2_reflections':1344}

def delta_checks():
    # All 1024 labelled graphs on five coordinates. Verify the complete
    # edge characterization via coordinate exposure and midpoint witnesses.
    n=5;edges=list(combinations(range(n),2));total=0;longer=0
    for bits in range(1<<len(edges)):
        A=[0]*n
        for k,(i,j) in enumerate(edges):
            if bits>>k&1:A[i]|=1<<j;A[j]|=1<<i
        def feasible(D):
            I=list(points(D))
            rows=[sum((A[i]>>j&1)<<k for k,j in enumerate(I)) for i in I]
            return rank2(rows)==len(I)
        F={D for D in range(1<<n) if feasible(D)}
        assert all(D.bit_count()%2==0 for D in F)
        for X,Y in combinations(F,2):
            D=X^Y
            if D.bit_count()>2:
                assert any(X^mask(S) in F and Y^mask(S) in F for S in combinations(points(D),2))
                longer+=1
            total+=1
    return {'labelled_graphs':1024,'feasible_pairs_tested':total,'longer_pair_midpoint_witnesses':longer}

if __name__=='__main__':
    result={'reflection_generators':reflection_checks(),
            'delta_matroid_edges':delta_checks()}
    (ROOT/'structural_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
