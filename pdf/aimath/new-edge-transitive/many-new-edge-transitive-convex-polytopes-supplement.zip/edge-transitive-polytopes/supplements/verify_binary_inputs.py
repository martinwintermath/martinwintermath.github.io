#!/usr/bin/env python3
"""Exact finite inputs for edge-transitive polytopes. Python >=3.10."""
from itertools import combinations
from collections import Counter, defaultdict
import json


def rank2(rows):
    piv = {}
    for x in rows:
        while x:
            p = x.bit_length() - 1
            if p in piv:
                x ^= piv[p]
            else:
                piv[p] = x
                break
    return len(piv)


def affine_rank(points):
    return rank2([1 | (a << 1) for a in points])


def moment(word, m):
    rows = [0] * (m + 1)
    for a in range(1 << m):
        if (word >> a) & 1:
            u = 1 | (a << 1)
            for i in range(m + 1):
                if (u >> i) & 1:
                    rows[i] ^= u
    return rows


def syndrome(word, m):
    s = 0
    for a in range(1 << m):
        if (word >> a) & 1:
            s ^= a
    return s


def check_moment_and_faces():
    m, n = 3, 8
    feasible = {w for w in range(1 << n)
                if w.bit_count() % 2 == 0 and rank2(moment(w, m)) == m + 1}
    bases = {sum(1 << a for a in B) for B in combinations(range(n), 4)
             if affine_rank(B) == 4}
    assert feasible == bases and len(feasible) == 56
    assert {w.bit_count() for w in feasible} == {4}
    pairs = [((1 << a) | (1 << b)) for a, b in combinations(range(n), 2)]
    assert {sum(w ^ p in feasible for p in pairs) for w in feasible} == {12}
    # Exhaustive simultaneous-flip witnesses for all longer feasible pairs.
    for x, y in combinations(sorted(feasible), 2):
        D = x ^ y
        if D.bit_count() > 2:
            assert any(p & D == p and x ^ p in feasible and y ^ p in feasible
                       for p in pairs)
    face = [w for w in bases if (w & 3) == 3 and not (w & ((1 << 5) | (1 << 7)))]
    assert len(face) == 5
    free = [2, 3, 4, 6]
    face_pairs = {tuple(a for a in free if w >> a & 1) for w in face}
    assert all(len(p) == 2 for p in face_pairs)
    assert len(set(combinations(free, 2)) - face_pairs) == 1

    H = {w for w in range(1 << n) if w.bit_count() % 2 == 0 and syndrome(w, m)}
    assert len(H) == 112
    assert {sum(w ^ p in H for p in pairs) for w in H} == {24}
    for x, y in combinations(sorted(H), 2):
        D = x ^ y
        if D.bit_count() > 2:
            assert any(p & D == p and x ^ p in H and y ^ p in H for p in pairs)
    D = [0, 1, 2, 4]
    mask = sum(1 << a for a in D)
    assert len([w for w in H if w & ~mask == 0]) == 7

    # Local rank-update counts: all even ranks below full rank for m=3,4,5.
    rank_cases = []
    for m in [3, 4, 5]:
        n = 1 << m
        for r in range(2, m + 1, 2):
            # A0 = [[0,1],[1,1]] direct sum symplectic blocks and zero radical.
            A = [0] * (m + 1)
            A[0], A[1] = 2, 3
            for i in range(2, r, 2):
                A[i], A[i + 1] = 1 << (i + 1), 1 << i
            counts = [0] * n
            for a, b in combinations(range(n), 2):
                rows = A[:]
                for c in [a, b]:
                    u = 1 | (c << 1)
                    for i in range(m + 1):
                        if u >> i & 1:
                            rows[i] ^= u
                s = rows[0] >> 1
                if rank2(rows) == r and s:
                    counts[a] += 1
                    counts[b] += 1
            h = 1 << (r - 1)
            expect = Counter({n - h // 2 - 1: h, 2 * h - 2: n - h})
            assert Counter(counts) == expect
            rank_cases.append([m, r, dict(sorted(Counter(counts).items()))])
    # Complete moment-space count for m=5, without enumerating 2^32 cube words.
    m, n = 5, 32
    monomials = [sum(1 << a for a in range(n) if all(a >> i & 1 for i in S))
                 for k in range(3) for S in combinations(range(m), k)]
    assert rank2(monomials) == 16
    assert all(moment(w, m) == [0] * 6 for w in monomials)
    kernel = [0]
    for w in monomials:
        kernel += [x ^ w for x in kernel]
    assert len(kernel) == 65536
    assert min(w.bit_count() for w in kernel if w) == 8
    nonsingular = 0
    cross = list(combinations(range(1, 6), 2))
    for bits in range(1 << 15):
        A = [0] * 6
        for i in range(1, 6):
            if bits >> (i - 1) & 1:
                A[0] ^= 1 << i
                A[i] ^= 1 | (1 << i)
        for j, (a, b) in enumerate(cross, 5):
            if bits >> j & 1:
                A[a] ^= 1 << b
                A[b] ^= 1 << a
        nonsingular += rank2(A) == 6
    assert nonsingular == 13888
    return {"moment_P3_vertices": 56, "moment_P3_degree": 12,
            "Hamming_m3_vertices": 112, "Hamming_m3_degree": 24,
            "AG32_square_pyramid_face_vertices": 5,
            "Hamming_octahedral_pyramid_face_vertices": 7,
            "rank_update_cases": rank_cases,
            "moment_m5_nonsingular_even_matrices": nonsingular,
            "moment_m5_kernel_size": len(kernel),
            "moment_m5_vertices": nonsingular * len(kernel)}


def golay_code():
    g = sum(1 << i for i in [11, 9, 7, 6, 5, 1, 0])
    generators = []
    for i in range(12):
        w = g << i
        generators.append(w | ((w.bit_count() & 1) << 23))
    code = [0]
    for g in generators:
        code += [w ^ g for w in code]
    assert len(set(code)) == 4096
    assert Counter(w.bit_count() for w in code) == Counter({0: 1, 8: 759,
                                                         12: 2576, 16: 759, 24: 1})
    return generators, code


def check_golay():
    generators, code = golay_code()
    piv = {}
    for x in generators:
        while x:
            p = x.bit_length() - 1
            if p in piv:
                x ^= piv[p]
            else:
                piv[p] = x
                break

    def reduce_word(x):
        for p in sorted(piv, reverse=True):
            if x >> p & 1:
                x ^= piv[p]
        return x

    errors = defaultdict(list)
    distance = {}
    for k in range(5):
        for S in combinations(range(24), k):
            w = sum(1 << a for a in S)
            key = reduce_word(w)
            distance.setdefault(key, k)
            if k == 4:
                errors[key].append(w)
    assert len(distance) == 4096  # All cosets have a leader of weight <=4.
    assert Counter(distance.values()) == Counter({0: 1, 1: 24, 2: 276,
                                                 3: 2024, 4: 1771})
    assert len(errors) == 1771
    for key, tetrads in errors.items():
        assert distance[key] == 4 and len(tetrads) == 6
        union = 0
        for T in tetrads:
            assert not union & T
            union |= T
        assert union == (1 << 24) - 1
    octads = [w for w in code if w.bit_count() == 8]
    five_sets = Counter()
    for w in octads:
        for S in combinations([a for a in range(24) if w >> a & 1], 5):
            five_sets[S] += 1
    assert len(five_sets) == 42504 and set(five_sets.values()) == {1}
    B = next(S for S in combinations(range(24), 6)
             if not any(sum(1 << a for a in S) & ~O == 0 for O in octads))
    fixed, free = B[:2], B[2:]
    base = sum(1 << a for a in fixed)
    feasible = []
    for k in range(5):
        for S in combinations(free, k):
            w = base | sum(1 << a for a in S)
            if distance[reduce_word(w)] == 4:
                feasible.append(S)
    assert Counter(map(len, feasible)) == Counter({2: 6, 4: 1})
    return {"Golay_code_size": 4096, "Golay_coset_distance_counts":
            dict(sorted(Counter(distance.values()).items())),
            "Golay_sextets": 1771, "Golay_face_six_set": list(B),
            "Golay_octahedral_pyramid_face_vertices": 7}



if __name__ == "__main__":
    result={"binary_checks":check_moment_and_faces(),"Golay_checks":check_golay()}
    Path=__import__("pathlib").Path
    (Path(__file__).resolve().parent/"binary_results.json").write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
