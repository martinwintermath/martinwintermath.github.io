#!/usr/bin/env python3
"""Exact seed-polytope verification. Python >=3.10; standard library only.

The two downloaded ATLAS files are data, parsed as permutation cycles.
No GAP text is executed. All checks use integer arithmetic.
"""
from pathlib import Path
from itertools import combinations, product, permutations
from collections import Counter, deque
from time import perf_counter
import re, json, hashlib
from verify_binary_inputs import rank2, affine_rank, moment, syndrome

ROOT = Path(__file__).resolve().parent
RESULTS = {}

def record(name, value):
    RESULTS[name] = value
    print(name, json.dumps(value), flush=True)

def comp(a, b):
    return tuple(a[i] for i in b)

def inv(a):
    p = [0]*len(a)
    for i,j in enumerate(a): p[j] = i
    return tuple(p)

def mask(S): return sum(1<<i for i in S)

def points(w):
    while w:
        b = w & -w
        yield b.bit_length()-1
        w ^= b

def permword(p, w): return mask(p[i] for i in points(w))

def orbit(start, gens, action):
    identity = tuple(range(len(gens[0])))
    T = {start:identity}
    todo = deque([start])
    while todo:
        x = todo.popleft()
        for g in gens:
            y = action(g,x)
            if y not in T:
                T[y] = comp(g,T[x]); todo.append(y)
    return T

def schreier(start, gens, action):
    T = orbit(start, gens, action)
    inverses = {x:inv(t) for x,t in T.items()}
    identity = tuple(range(len(gens[0])))
    H = set()
    for x,t in T.items():
        for g in gens:
            h = comp(inverses[action(g,x)],comp(g,t))
            if h != identity: H.add(h)
    return T, sorted(H)

def closure(gens, n):
    identity = tuple(range(n))
    seen = {identity}; todo = deque([identity])
    while todo:
        p = todo.popleft()
        for g in gens:
            q = comp(g,p)
            if q not in seen: seen.add(q); todo.append(q)
    return seen

def reduce_small_group(candidates, n, expected):
    chosen=[]; G={tuple(range(n))}
    for g in candidates:
        if g not in G:
            chosen.append(g); G=closure(chosen,n)
            assert len(G)<=expected
        if len(G)==expected: break
    assert len(G)==expected
    assert all(g in G for g in candidates)
    return chosen,G

def parse_atlas(name):
    text=(ROOT/name).read_text()
    p=list(range(24))
    for c in re.findall(r'\(([^()]+)\)',text):
        c=[int(x)-1 for x in re.findall(r'\d+',c)]
        for a,b in zip(c,c[1:]+c[:1]): p[a]=b
    assert sorted(p)==list(range(24))
    return tuple(p)

def binary_span(rows):
    piv={}
    for w in rows:
        while w:
            i=w.bit_length()-1
            if i in piv: w^=piv[i]
            else: piv[i]=w; break
    words=[0]
    for g in piv.values(): words += [w^g for w in words]
    return piv, words

def reduceword(w,piv):
    for i in sorted(piv,reverse=True):
        if w>>i&1: w^=piv[i]
    return w

def check_mathieu():
    gens=[parse_atlas('M24.g1'),parse_atlas('M24.g2')]
    octads=set(orbit(mask([0,1,2,3,4,10,16,23]),gens,permword))
    assert len(octads)==759
    piv,code=binary_span(octads)
    assert len(piv)==12 and len(code)==4096
    assert Counter(w.bit_count() for w in code)==Counter({0:1,8:759,12:2576,16:759,24:1})
    assert set(w for w in code if w.bit_count()==8)==octads
    assert all(permword(g,w) in set(code) for g in gens for w in piv.values())
    five={}
    nonbases=set()
    for O in octads:
        for S in combinations(points(O),5):
            f=mask(S); assert f not in five; five[f]=O
        nonbases.update(mask(S) for S in combinations(points(O),6))
    assert len(five)==42504 and len(nonbases)==21252
    assert max((O&P).bit_count() for O,P in combinations(octads,2))==4
    F=min(five)
    T,H=schreier(F,gens,permword)
    assert len(T)==42504
    hg,group=reduce_small_group(H,24,5760)
    allowed=list(points(((1<<24)-1)^five[F]))
    pair_orbit=orbit((allowed[0],allowed[1]),hg,lambda p,x:(p[x[0]],p[x[1]]))
    assert len(pair_orbit)==16*15
    bases=set(mask(S) for S in combinations(range(24),6))-nonbases
    assert len(bases)==113344
    assert len(orbit(min(bases),gens,permword))==len(bases)
    degrees=Counter()
    for B in bases:
        degree=0
        for b in points(B):
            f=B^(1<<b)
            degree += 18-(five[f]&~B).bit_count()
        degrees[degree]+=1
    assert degrees==Counter({90:113344})
    five_action={tuple(p[i] for i in points(F)) for p in group}
    assert len(five_action)==120  # full S5, proves 5-transitivity too
    # Every coordinate transposition fails to preserve the block system.
    assert all(any(permword(tuple(j if a==i else i if a==j else a for a in range(24)),O) not in octads
                   for O in octads) for i,j in combinations(range(24),2))
    # The quotient has a normal subgroup of order 60 coming from A5
    # on the preserved five-set.
    quotient={tuple(p[i] for i in points(five[F])) for p in group}
    assert len(quotient)==360
    # Faithful 8-point action; three remaining octad coordinates give a
    # quotient S3, with a kernel of order 60.
    other=list(points(five[F]&~F))
    q3={tuple(p[i] for i in other) for p in group}
    assert len(q3)==6
    record('large_Witt',{'octads':759,'bases':len(bases),'degree_counts':dict(degrees),
        'five_set_orbit':len(T),'five_set_stabilizer_order':len(group),
        'M24_order_from_orbit_stabilizer':len(T)*len(group),'five_set_action_order':len(five_action),
        'ordered_allowed_pair_orbit':len(pair_orbit),'octad_action_quotient_order':len(quotient),
        'three_point_quotient_order':len(q3),'reflection_transpositions':0})
    # Restrict the dodecad stabilizer to obtain M12 and its Witt design.
    D=min(w for w in code if w.bit_count()==12)
    TD,HD=schreier(D,gens,permword)
    assert len(TD)==2576
    labels=list(points(D)); index={a:i for i,a in enumerate(labels)}
    candidates=sorted(set(tuple(index[p[a]] for a in labels) for p in HD))
    m12gens,m12=reduce_small_group(candidates,12,95040)
    hexads={mask(index[a] for a in points(O&D)) for O in octads if (O&D).bit_count()==6}
    assert len(hexads)==132
    five12=Counter(mask(S) for H in hexads for S in combinations(points(H),5))
    assert len(five12)==792 and set(five12.values())=={1}
    assert all(permword(g,H) in hexads for g in m12gens for H in hexads)
    all12=(1<<12)-1
    assert {all12^H for H in hexads}==hexads
    bases12={mask(S) for S in combinations(range(12),6)}-hexads
    assert len(bases12)==792
    assert len(orbit(min(bases12),m12gens,permword))==792
    f=min(five12); forbidden=next(H for H in hexads if H&f==f)
    allowed12=list(points(all12^forbidden))
    h12=[p for p in m12 if permword(p,f)==f]
    assert len(h12)==120
    assert len({(p[allowed12[0]],p[allowed12[1]]) for p in h12})==30
    pairs=[(1<<a)|(1<<b) for a,b in combinations(range(12),2)]
    assert Counter(sum(B^p in bases12 for p in pairs) for B in bases12)==Counter({30:792})
    assert all(any(permword(tuple(j if a==i else i if a==j else a for a in range(12)),H) not in hexads
                   for H in hexads) for i,j in combinations(range(12),2))
    record('small_Witt',{'hexads':132,'bases':792,'group_order':95040,
        'five_set_stabilizer_order':120,'ordered_allowed_pair_orbit':30,'degree':30,
        'identically_self_dual':True,'reflection_transpositions':0})
    del group,m12,bases,TD,HD
    # Cosets and sextet local actions, in the same ATLAS labelling.
    distances={}; leaders={}
    for k in range(5):
        for S in combinations(range(24),k):
            w=mask(S); key=reduceword(w,piv)
            distances.setdefault(key,k)
            if k==4: leaders.setdefault(key,[]).append(w)
    assert len(distances)==4096 and len(leaders)==1771
    sextets={tuple(sorted(v)) for v in leaders.values()}
    def sextet_action(p,S): return tuple(sorted(permword(p,T) for T in S))
    S=min(sextets)
    TS,HS=schreier(S,gens,sextet_action)
    assert len(TS)==1771 and set(TS)==sextets
    # No enumeration of the 244-million-element group is needed.
    first=next(points(S[0])); second=next(points(S[1]))
    op=orbit((first,second),HS,lambda p,x:(p[x[0]],p[x[1]]))
    assert len(op)==480
    lookup={}
    for key,S in leaders.items():
        assert len(S)==6
        union=0
        for block in S:
            assert union&block==0
            union|=block
        assert union==(1<<24)-1
        blocks=[0]*24
        for T in S:
            for a in points(T): blocks[a]=T
        lookup[key]=blocks
    flips=[(a,b,(1<<a)|(1<<b),reduceword((1<<a)|(1<<b),piv))
           for a,b in combinations(range(24),2)]
    for key,blocks in lookup.items():
        assert sum(distances[key^delta]==4 for a,b,p,delta in flips)==240
        for a,b,p,delta in flips:
            assert (distances[key^delta]==4)==(blocks[a]!=blocks[b])
    excluded_degree=Counter()
    for key,d in distances.items():
        if d in [0,2]:
            excluded_degree[(d,sum(distances[key^delta] in [0,2] for a,b,p,delta in flips))]+=1
    assert excluded_degree==Counter({(0,276):1,(2,45):276})
    record('Golay_group_and_edges',{'code_size':4096,'coset_counts':dict(Counter(distances.values())),
        'sextet_orbit':len(TS),'ordered_cross_tetrad_pair_orbit':len(op),
        'exhaustive_coset_flip_tests':1771*276,'degree':240,
        'excluded_coset_degree_counts':{str(k):v for k,v in excluded_degree.items()}})
    (ROOT/'mathieu_certificates.json').write_text(json.dumps({'M24_generators':gens,
        'large_Witt_five_set':list(points(F)),'large_Witt_stabilizer_generators':hg,
        'M12_labels_in_M24':labels,'M12_generators':m12gens,
        'sextet':S,'sextet_stabilizer_generators':HS},indent=2))
    return piv,code,distances,leaders,lookup,flips

def check_deep_midpoints(data):
    piv,code,distances,leaders,lookup,flips=data
    key0=min(leaders); x=leaders[key0][0]; blocks0=lookup[key0]
    total=0; nonedges=0
    for key,L in leaders.items():
        leader=L[0]; blocks=lookup[key]
        for c in code:
            y=leader^c; D=x^y; total+=1
            if D.bit_count()<=2: continue
            for a in points(D):
                available=D&~blocks0[a]&~blocks[a]
                if available:
                    b=next(points(available)); pair=(1<<a)|(1<<b)
                    delta=reduceword(pair,piv)
                    assert distances[key0^delta]==distances[key^delta]==4
                    # pair subset D gives x+y=(x^pair)+(y^pair) in R^24.
                    assert pair&D==pair and D!=pair
                    nonedges+=1; break
            else: raise AssertionError(('no midpoint witness',x,y))
    assert total==7254016 and nonedges==7253775
    record('Golay_complete_fixed_vertex_midpoints',{'vertices':total,'nonedge_witnesses':nonedges})

def affine_generators(m):
    n=1<<m; out=[]
    for i in range(m): out.append(tuple(a^(1<<i) for a in range(n)))
    for i in range(m):
        for j in range(m):
            if i!=j: out.append(tuple(a^(((a>>j)&1)<<i) for a in range(n)))
    return out

def check_small_binary():
    # H4: all 30,720 words, every local edge and every other pair from
    # a fixed vertex; this checks longer-pair exclusion independently.
    m=4;n=16;pairs=[(1<<a)|(1<<b) for a,b in combinations(range(n),2)]
    words={w for w in range(1<<n) if w.bit_count()%2==0 and syndrome(w,m)}
    assert len(words)==30720
    x=min(words); neigh={x^p for p in pairs if x^p in words}; assert len(neigh)==112
    nonedges=0
    for y in words-{x}-neigh:
        D=x^y
        assert any(p&D==p and x^p in words and y^p in words for p in pairs)
        nonedges+=1
    # Vertex transitivity follows from the independently checked syndrome
    # and kernel structure, local transitivity from the full affine group.
    G=closure(affine_generators(3),8); assert len(G)==1344
    bases={mask(B) for B in combinations(range(8),4) if affine_rank(B)==4}
    B=min(bases); bg=[p for p in G if permword(p,B)==B]
    neighbors={B^p for p in [(1<<a)|(1<<b) for a,b in combinations(range(8),2)] if B^p in bases}
    assert len(bg)==24 and len({permword(p,next(iter(neighbors))) for p in bg})==12
    # All 896 signed affine-base vertices; exact midpoint certificates for
    # all 871 nonneighbors of one vertex, including sign-only pairs.
    signed=[]
    for B in bases:
        coords=list(points(B))
        for signs in product([-1,1],repeat=4):
            v=[0]*8
            for a,s in zip(coords,signs): v[a]=s
            signed.append(tuple(v))
    signed=set(signed); v=tuple(1 if B>>a&1 else 0 for a in range(8))
    nb={w for w in signed if sum((a-b)**2 for a,b in zip(v,w))==2}
    assert len(nb)==24
    # Hash all sums involving x. For each proposed nonedge, search another
    # vertex z and compute its required partner x+y-z exactly.
    for w in signed-{v}-nb:
        s=tuple(a+b for a,b in zip(v,w))
        assert any(z!=v and z!=w and tuple(a-b for a,b in zip(s,z)) in signed for z in signed)
    record('additional_small_binary',{'H4_vertices':len(words),'H4_degree':112,
        'H4_nonedge_witnesses':nonedges,'AG32_affine_group_order':1344,
        'AG32_base_neighbor_orbit':12,'signed_AG32_vertices':896,'signed_AG32_degree':24,
        'signed_AG32_nonedge_witnesses':871})

def congruence(A,p,m):
    # Recover the affine (m+1)x(m+1) matrix from its action on 0,e_i.
    b=p[0]; columns=[1|(b<<1)]+[(p[1<<i]^b)<<1 for i in range(m)]
    R=[sum(((columns[j]>>i)&1)<<j for j in range(m+1)) for i in range(m+1)]
    return [sum((sum((A[k]&R[j]).bit_count()&1 for k in points(R[i]))&1)<<j
                for j in range(m+1)) for i in range(m+1)]

def check_moments():
    m=5;n=32
    A=(2,3,8,4,32,16)
    gens=affine_generators(m)
    T=orbit(A,gens,lambda p,A:tuple(congruence(A,p,m)))
    assert len(T)==13888 and all(rank2(A)==6 for A in T)
    def local(A):
        out=[]
        for a,b in combinations(range(n),2):
            B=list(A)
            for c in [a,b]:
                u=1|(c<<1)
                for i in points(u): B[i]^=u
            if rank2(B)==6: out.append((a,b))
        return out
    E=local(A); assert len(E)==240
    _,H=schreier(A,gens,lambda p,A:tuple(congruence(A,p,m)))
    op=orbit(E[0],H,lambda p,e:tuple(sorted((p[e[0]],p[e[1]]))))
    assert len(op)==240
    neigh=[set() for _ in range(n)]
    for a,b in E: neigh[a].add(b);neigh[b].add(a)
    antipodal=[]; other=Counter()
    for a,b in combinations(range(n),2):
        if b not in neigh[a]:
            c=len(neigh[a]&neigh[b])
            if c==0: antipodal.append((a,b))
            else: other[c]+=1
    assert len(antipodal)==16 and set(other)=={8}
    # Verify the Woodbury identity and simultaneous flip witnesses at every
    # feasible endpoint differing on 4 or 6 coordinates from a canonical
    # affine-basis word (1,0),(1,e_i), i=1..5.
    x=mask([0]+[1<<i for i in range(m)])
    assert rank2(moment(x,m))==6
    tested=feasible=0
    for k in [4,6]:
        for Dcoords in combinations(range(n),k):
            D=mask(Dcoords); y=x^D;tested+=1
            if rank2(moment(y,m))!=6: continue
            feasible+=1
            assert any(rank2(moment(x^mask(pair),m))==6 and rank2(moment(y^mask(pair),m))==6
                       for pair in combinations(Dcoords,2))
    # Affine basis face size: |AGL(5,2)|/6!, compared with total vertex count.
    order=n
    for i in range(m):order*=n-(1<<i)
    assert order==319979520 and order//720==444416
    record('moment_m5_orbit_and_edges',{'nonsingular_moment_orbit':len(T),
        'local_edge_orbit':len(op),'degree':len(E),'antipodal_pairs':len(antipodal),
        'other_nonadjacent_common_neighbors':dict(other),'rank_update_sets_tested':tested,
        'feasible_longer_pairs_with_witness':feasible,'affine_basis_facet_vertices':order//720})

if __name__=='__main__':
    start=perf_counter()
    check_small_binary()
    data=check_mathieu()
    check_deep_midpoints(data)
    check_moments()
    record('runtime',{'seconds':round(perf_counter()-start,3),
        'atlas_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['M24.g1','M24.g2']}})
    (ROOT/'seed_results.json').write_text(json.dumps(RESULTS,indent=2))
