#!/usr/bin/env python3
"""Exact parameter tables and finite reflection data. Python >=3.10."""
from itertools import combinations, product
from math import factorial
from pathlib import Path
from collections import Counter
import json
from verify_seed_polytopes import (mask, points, comp, inv, orbit, closure,
    affine_generators, parse_atlas, binary_span, schreier, reduce_small_group)

ROOT=Path(__file__).resolve().parent

def cycle_index(p):
    assert comp(p,p)==tuple(range(len(p)))
    return sum(i!=p[i] for i in range(len(p)))//2

def uniform_coincidence():
    """Enumerate H3 and the D8 root graph; certify their local difference."""
    from verify_binary_inputs import syndrome
    hamming=[w for w in range(256) if w.bit_count()%2==0 and syndrome(w,3)]
    roots=[]
    for i,j in combinations(range(8),2):
        for a,b in product([-1,1],repeat=2):
            v=[0]*8
            v[i],v[j]=a,b
            roots.append(tuple(v))
    def graph_stats(vertices,adjacent,expected_local):
        neighbors=[{j for j,y in enumerate(vertices) if i!=j and adjacent(x,y)}
                   for i,x in enumerate(vertices)]
        assert len(vertices)==112 and {len(n) for n in neighbors}=={24}
        local=Counter(len(neighbors[i]&neighbors[j])
                      for i,n in enumerate(neighbors) for j in n)
        assert local==Counter({expected_local:112*24})
        return {'vertices':len(vertices),'degree':24,
                'edges':sum(map(len,neighbors))//2,
                'induced_neighbor_graph_degree':expected_local}
    h=graph_stats(hamming,lambda x,y:(x^y).bit_count()==2,10)
    r=graph_stats(roots,lambda x,y:sum((a-b)**2 for a,b in zip(x,y))==2,11)
    assert all(sum(a*a for a in v)==2 for v in roots)
    assert (1<<8)*factorial(8)==10321920
    assert 16*1344==21504
    return {'H3':h,'D8_root_polytope':r,'dimension':8,'radius_squared':2,
            'edge_length_squared':2,'lambda2':12,
            'H3_symmetry_order':21504,'D8_symmetry_order':10321920}

def matroid_facet_data(s,r,blocks):
    # The proof identifies exactly these flats: sets of size <=r-2,
    # block hyperplanes, and the whole set. The script checks the design
    # inputs that guarantee connected deletion/contraction and flacets.
    counts={k:Counter(mask(T) for H in blocks for T in combinations(points(H),k))
            for k in [2,3,r-1]}
    assert len(counts[r-1])==__import__('math').comb(s,r-1)
    assert set(counts[r-1].values())=={1}
    assert min(counts[2].values())>max(counts[3].values())
    h=next(iter(blocks)).bit_count()
    assert min(counts[2].values())*(h-2)==min(counts[3].values())*(s-2)
    return {'blocks':len(blocks),'coordinate_facets':2*s,
            'facets':len(blocks)+2*s,'pair_block_count':min(counts[2].values()),
            'triple_block_count':min(counts[3].values())}

def data_and_involutions():
    # Reconstruct code and M12 independently of stored certificate output.
    gens=[parse_atlas('M24.g1'),parse_atlas('M24.g2')]
    octads=set(orbit(mask([0,1,2,3,4,10,16,23]),gens,
                     lambda p,w:mask(p[i] for i in points(w))))
    _,code=binary_span(octads)
    D=min(w for w in code if w.bit_count()==12)
    labels=list(points(D));idx={a:i for i,a in enumerate(labels)}
    _,H=schreier(D,gens,lambda p,w:mask(p[i] for i in points(w)))
    candidates=sorted(set(tuple(idx[p[a]] for a in labels) for p in H))
    m12gens,m12=reduce_small_group(candidates,12,95040)
    involutions=[p for p in m12 if p!=tuple(range(12)) and
                 comp(p,p)==tuple(range(12))]
    spectrum=Counter(cycle_index(p) for p in involutions)
    assert spectrum==Counter({4:495,6:396})
    a=next(p for p in involutions if cycle_index(p)==4)
    conjugates=list(orbit(a,m12gens,lambda p,a:comp(comp(p,a),inv(p))))
    assert len(conjugates)==495
    _,generated=reduce_small_group(sorted(conjugates),12,95040)
    assert generated==m12
    hexads={mask(idx[a] for a in points(O&D)) for O in octads if (O&D).bit_count()==6}
    agl=closure(affine_generators(3),8)
    affine_invol=Counter(cycle_index(p) for p in agl if p!=tuple(range(8)) and
                        comp(p,p)==tuple(range(8)))
    assert min(affine_invol)==2
    # A representative of ATLAS class 2A: exact word and conjugacy orbit.
    word='ababababbababababbababababbababababb'
    p=tuple(range(24))
    for c in word:p=comp(p,gens['ab'.index(c)])
    assert comp(p,p)==tuple(range(24)) and cycle_index(p)==8
    conjugates24=orbit(p,gens,lambda g,a:comp(comp(g,a),inv(g)))
    assert len(conjugates24)==11385
    assert all(cycle_index(a)==8 for a in conjugates24)
    planes={mask(T) for T in combinations(range(8),4)
            if __import__('verify_binary_inputs').affine_rank(T)==3}
    assert len(planes)==14
    return {'M12_involution_indices':dict(spectrum),
        'M12_index4_conjugacy_class_size':495,'M12_generated_order':len(generated),
        'AGL32_involution_indices':dict(affine_invol),
        'M24_index8_representative':p,'M24_index8_class_size':11385,
        'facet_checks':{'affine':matroid_facet_data(8,4,planes),
            'small_Witt':matroid_facet_data(12,6,hexads),
            'large_Witt':matroid_facet_data(24,6,octads)}}

def parameter_tables():
    seeds=[('affine',8,4,56,12,1344,2,30),
           ('small_Witt',12,6,792,30,95040,4,156),
           ('large_Witt',24,6,113344,90,244823040,8,807)]
    bases=[];signed=[]
    for name,s,r,n,degree,g,k,facets in seeds:
        bases.append({'name':name,'dimension':s-1,'vertices':n,'degree':degree,
            'edges':n*degree//2,'facets':facets,'radius_squared_numerator':r*(s-r),
            'radius_squared_denominator':s,'lambda2':degree*s//(r*(s-r)),
            'k_min':k,'central':s==2*r,'group_order':g*(2 if s==2*r else 1)})
        for rank in ([r,s-r] if name=='large_Witt' else [r]):
            v=n*(1<<rank);d=degree*2
            assert d%rank==0
            signed.append({'name':name,'rank':rank,'dimension':s,'vertices':v,
                'degree':d,'edges':v*d//2,'radius_squared':rank,'lambda2':d//rank,
                'k_min':k,'central':True,'group_order':(1<<s)*g})
    hamming=[];moments=[]
    for m in [3,4,5,7]:
        s=1<<m
        agl=s
        for i in range(m):agl*=s-(1<<i)
        v=(s-1)*(1<<(s-m-1));d=s*(s-2)//2
        hamming.append({'m':m,'dimension':s,'vertices':v,'degree':d,
            'edges':v*d//2,'radius_squared':s//4,'lambda2':2*(s-2),
            'k_min':s//4,'group_order':(1<<(s-m-1))*agl})
        if m>=5 and m%2:
            h=(m+1)//2
            factor=1
            for j in range(1,h+1):factor*=(1<<(2*j-1))-1
            v=(1<<(s-h*h-1))*factor;d=s*(s-2)//4
            moments.append({'m':m,'dimension':s,'vertices':v,'degree':d,
                'edges':v*d//2,'radius_squared':s//4,'lambda2':s-2,
                'k_min':s//4,'group_order':(1<<(s-1-m-m*(m-1)//2))*agl})
    golay={'dimension':24,'vertices':7254016,'degree':240,
        'edges':870481920,'radius_squared':6,'lambda2':40,
        'k_min':8,'central':True,'group_order':4096*244823040}
    assert signed[2]['vertices']==golay['vertices'] and signed[2]['degree']!=golay['degree']
    return {'base_polytopes':bases,'signed_lifts':signed,'Hamming':hamming,
            'moments':moments,'Golay_deep':golay}

if __name__=='__main__':
    result={'parameters':parameter_tables(),'finite_group_and_facet_checks':data_and_involutions(),
            'uniform_parameter_coincidence':uniform_coincidence()}
    (ROOT/'parameter_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
